/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.funiturestorageq2;

/**
 *
 * @author Student
 */
public class FuniturestorageQ2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
