/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.furniturestoragereport;

/**
 *
 * @author Student
 */
public class FurnitureStorageReport {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
